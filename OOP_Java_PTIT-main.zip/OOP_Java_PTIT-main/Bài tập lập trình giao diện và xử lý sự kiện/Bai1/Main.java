// Created by Nguyễn Mạnh Quân

package Bai1;

public class Main
{
    public static void main(String[] args)
    {
        new Frame();
    }
}
