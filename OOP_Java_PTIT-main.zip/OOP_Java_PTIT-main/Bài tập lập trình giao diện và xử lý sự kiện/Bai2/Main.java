// Created by Nguyễn Mạnh Quân

package Bai2;

public class Main
{
    public static void main(String[] args)
    {
        new Frame();
    }
}
