## BÀI TẬP LẬP TRÌNH GIAO DIỆN VÀ XỬ LÝ SỰ KIỆN

Yêu cầu chung: Sinh viên **KHÔNG** sử dụng kéo thả.

1. Viết chương trình tạo một hộp chọn màu. Khi chọn đến màu nào thì màu màn hình chuyển sang màu đó (có thể chọn màu dạng List, ComboBox hoặc
ColorChooser).

2. Viết chương trình vẽ các hình cơ bản: hình vuông, hình chữ nhật, hình tròn,
hình đa giác. Cho phép người dùng chọn loại hình vẽ, kiểu rỗng hay đặc và
chọn màu của hình. Cải tiến chương trình để có thể thay đổi các tham số của
từng hình khi vẽ.

3. Viết chương trình vẽ lên giao diện một đồng hồ có ba kim giờ, phút, giây và
các số 3, 6, 9, 12. Ở phía dưới, hiển thị thêm một đồng hồ khác với giá trị số
giờ:phút:giây (định dạng 24h).

4. Viết chương trình mô phỏng máy tính bỏ túi với các chức năng cơ bản: cộng,
trừ, nhân, chia, lũy thừa, căn bậc hai.

5. Viết chương trình cho phép chọn file ảnh trong ổ cứng và hiển thị lên giao
diện. Cho phép thay đổi kích thước khung hiển thị và hiển thị nhiều ảnh.

6. Tạo giao diện cho ít nhất 5 bài trong danh sách các bài tập cơ bản làm quen với Java. Chú ý bắt lỗi người dùng khi nhập.

7. Tạo giao diện cho các bài tập viết class. Trong đó có nút nhấn cho phép đọc
thông tin từ file và hiện ra trên Bảng (JTable), nút sắp xếp cho phép hiện ra
danh sách đã sắp xếp.
