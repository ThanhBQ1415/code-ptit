// Created by Nguyễn Mạnh Quân

package Bai5;

public class Main
{
    public static void main(String[] args)
    {
        new Frame();
    }
}
