// Created by Nguyễn Mạnh Quân

import java.util.*;

public class CHELLO
{
    public static void main(String[] args)
    {
        System.out.print("Hello PTIT.");
    }
}
