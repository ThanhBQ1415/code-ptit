// Created by Nguyễn Mạnh Quân at 17:48 on 12/11/2022

import java.io.*;
import java.util.*;

public class J07001
{
    public static void main(String[] args) throws IOException
    {
        Scanner sc = new Scanner(new File("DATA.in"));
        while (sc.hasNextLine())
            System.out.println(sc.nextLine());
    }
}
