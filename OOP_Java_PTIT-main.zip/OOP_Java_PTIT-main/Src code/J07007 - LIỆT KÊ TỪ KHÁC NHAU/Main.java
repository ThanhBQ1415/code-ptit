// Created by Nguyễn Mạnh Quân at 02:34 on 13/11/2022

package J07007;

import java.io.IOException;

public class Main
{
    public static void main(String[] args) throws IOException
    {
        WordSet ws = new WordSet("VANBAN.in");
        System.out.println(ws);
    }
}
