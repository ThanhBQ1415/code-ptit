package J07074;

public class MonHoc
{
    private String maMH;
    private String tenMH;
    private String soTC;

    public MonHoc(String maMH, String tenMH, String soTC)
    {
        this.maMH = maMH;
        this.tenMH = tenMH;
        this.soTC = soTC;
    }

    public String getMaMH()
    {
        return maMH;
    }

    public String getTenMH()
    {
        return tenMH;
    }
}
